// Variáveis para o animal
let cowX = 50;
let cowY = 300;
let cowSpeed = 2;

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(135, 206, 235); // Céu azul

  drawFazenda();
  drawAnimal();
  moveAnimal();
}

// Função para desenhar a fazenda
function drawFazenda() {
  // Campo
  fill(34, 139, 34); // Verde
  rect(0, 400, width, 200);

  // Sol
  fill(255, 204, 0);
  ellipse(700, 100, 80, 80);

  // Árvores
  fill(139, 69, 19); // Tronco
  rect(100, 350, 20, 50);
  fill(34, 139, 34); // Folhagem
  ellipse(110, 340, 60, 60);

  fill(139, 69, 19);
  rect(600, 350, 20, 50);
  fill(34, 139, 34);
  ellipse(610, 340, 60, 60);
}

// Função para desenhar o animal (vaca)
function drawAnimal() {
  // Corpo
  fill(255);
  rect(cowX, cowY, 80, 50);
  // Cabeça
  ellipse(cowX + 80, cowY + 10, 30, 30);
  // Olhos
  fill(0);
  ellipse(cowX + 85, cowY + 5, 5, 5);
  // Pernas
  stroke(0);
  line(cowX + 10, cowY + 50, cowX + 10, cowY + 70);
  line(cowX + 30, cowY + 50, cowX + 30, cowY + 70);
  line(cowX + 50, cowY + 50, cowX + 50, cowY + 70);
  line(cowX + 70, cowY + 50, cowX + 70, cowY + 70);
}

// Função para mover o animal
function moveAnimal() {
  cowX += cowSpeed;
  if (cowX > width || cowX < 0) {
    cowSpeed *= -1; // Muda a direção ao chegar na borda
  }
}

// Opcional: interatividade ao clicar na fazenda
function mousePressed() {
  // Se clicar na fazenda, o animal pula
  if (mouseX > cowX && mouseX < cowX + 80 && mouseY > cowY && mouseY < cowY + 50) {
    cowY -= 20; // Faz o animal "pular"
  }
}